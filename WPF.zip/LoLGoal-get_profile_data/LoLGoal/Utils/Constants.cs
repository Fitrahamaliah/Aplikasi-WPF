﻿using LoLGoal.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoLGoal.Utils
{
    public static class Constants
    {
        public static SummonerDTO Summoner { get; set; }
        public static string Region { get; set; }
    }
}
